import { GoogleGenAI } from "@google/genai";
import {
    StoredIdea,
    InitialAnalysisResult,
    SimilarIdeaReport,
    DuplicateIdeaReport,
    VisualInspirationBrief,
    IdeaClassification,
    CourseContext,
} from '../types';

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY is not defined. Please check your environment variables.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const analyzeIdeaSimilarity = async (
    idea: string,
    existingIdeas: StoredIdea[],
    courseContext: CourseContext
): Promise<InitialAnalysisResult> => {

    const existingProjectsDetails = existingIdeas.map((p, i) => `
    المشروع ${i}: 
    - العنوان: ${p.title}
    - المقرر: ${p.course}
    - وصف المشكلة: ${p.problemDescription}
    - الحل المقترح: ${p.proposedSolution}
    - رابط المشروع: ${p.link || 'لا يوجد'}
    - بريد التواصل: ${p.contactEmail || 'لا يوجد'}
    `).join('\n');

    const prompt = `
        أنت "مشرف أكاديمي ذكي وخبير". مهمتك تحليل الفكرة الجديدة المقدمة في سياق المقرر الدراسي المحدد ومقارنتها بقائمة المشاريع الحالية. يجب أن يكون تحليلك عميقًا ودقيقًا للغاية.

        **السياق الأكاديمي (الأكثر أهمية):**
        - اسم المقرر: "${courseContext.name}"
        - أهداف المقرر: ${courseContext.objectives.join('، ')}
        - مخرجات المقرر: ${courseContext.outcomes.join('، ')}
        
        **الفكرة الجديدة المقدمة:**
        "${idea}"

        **قائمة المشاريع الحالية:**
        ${existingProjectsDetails}

        **قواعد التحليل والتقييم الصارمة:**
        1.  **التركيز على الجوهر:** يجب أن تعطي الأولوية القصوى **للمشكلة الأساسية والحل المقترح**. التشابه في الفئة المستهدفة أو المجال وحده لا يعني أن الفكرة متشابهة. مثال: فكرة "تطبيق لتتبع السمنة عند الأطفال" مختلفة تمامًا عن فكرة "تطبيق لتقييد المحتوى الضار عن الأطفال"، على الرغم من أن كليهما يستهدف الأطفال.
        2.  **الأولوية للمقرر:** أعطِ وزنًا وأهمية أعلى بكثير للمشاريع الموجودة في نفس المقرر الدراسي ("${courseContext.name}").
        3.  **القاعدة الأكاديمية الخاصة:** إذا كانت الفكرة متطابقة بنسبة >70% مع مشروع آخر ولكن في **مقرر مختلف**، فيجب تصنيفها كـ **"SIMILAR"** وليس "DUPLICATE".
        4.  **التصنيف:**
            - **DUPLICATE (مكرر - تشابه 70% فأكثر):** تطابق شبه كامل في المشكلة والحل والسياق الأكاديمي مع مشروع آخر في **نفس المقرر**.
            - **SIMILAR (متشابه - تشابه 25% إلى 69%):** تشابه في المشكلة الأساسية أو الحل، ولكن مع اختلاف جوهري، أو تطابق كبير ولكن في مقرر مختلف.
            - **UNIQUE (فريد - تشابه أقل من 25%):** فكرة جديدة ومبتكرة.

        **المخرج المطلوب:**
        قم بالرد **فقط** بكائن JSON باللغة العربية بالهيكلية التالية:
        {
          "classification": "UNIQUE" | "SIMILAR" | "DUPLICATE",
          "justification": "شرح موجز جدًا من جملة واحدة فقط لسبب التصنيف. إذا كان السبب هو القاعدة الأكاديمية الخاصة، فاذكر: 'هناك مشروع مطابق لهذه الفكرة لكنه ينتمي لمقرر آخر. يمكنك تكييف الفكرة لتناسب أهداف مقررك الحالي.'",
          "similarToIndex": "في حالة SIMILAR أو DUPLICATE، قم بإرجاع رقم الفهرس (integer) الخاص بالمشروع الأكثر تطابقًا. وإلا، أرجع null.",
          "similarityPercentage": "رقم (integer) يمثل نسبة التشابه المئوية المقدرة. يجب أن تكون النسبة عالية جدًا (>90%) في حالة القاعدة الأكاديمية الخاصة.",
          "matchedProjectName": "في حالة SIMILAR أو DUPLICATE، قم بإرجاع اسم المشروع المطابق بالضبط (وليس رقمه). وإلا، أرجع null.",
          "matchedProjectCourse": "في حالة SIMILAR أو DUPLICATE، قم بإرجاع اسم مقرر المشروع المطابق. وإلا، أرجع null.",
          "matchedProjectLink": "في حالة SIMILAR أو DUPLICATE، قم بإرجاع رابط المشروع المطابق إن وجد. وإلا، أرجع null."
        }
    `;

    const result = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        },
    });
    
    const parsed = JSON.parse(result.text) as InitialAnalysisResult;
    if (!parsed.classification || !Object.values(IdeaClassification).includes(parsed.classification)) {
        throw new Error("AI response is missing or has an invalid 'classification' field.");
    }
     if ((parsed.classification === 'SIMILAR' || parsed.classification === 'DUPLICATE') && (typeof parsed.similarToIndex !== 'number')) {
        throw new Error(`AI classified as ${parsed.classification} but did not return a valid number for similarToIndex.`);
    }

    return parsed;
};

/**
 * 📋 Agent 2A: Similar Idea Reporter
 */
export const generateSimilarIdeaReport = async (
    userIdea: string,
    matchedIdea: StoredIdea
): Promise<SimilarIdeaReport> => {
     const prompt = `
        أنت خبير في تحليل المشاريع. تم تصنيف فكرة المستخدم على أنها "متشابهة" لمشروع موجود. مهمتك هي إنشاء تقرير تحليلي مفصل ومقارن.

        **فكرة المستخدم:** 
        "${userIdea}"

        **المشروع المشابه:**
        - العنوان: "${matchedIdea.title}"
        - المقرر: ${matchedIdea.course}
        - الحالة: ${matchedIdea.status}
        - تاريخ الإنشاء: ${matchedIdea.creationDate}
        - وصف المشكلة: ${matchedIdea.problemDescription}
        - الحل المقترح: ${matchedIdea.proposedSolution}
        - الرابط: ${matchedIdea.link || 'لا يوجد'}

        **المخرج المطلوب (JSON باللغة العربية):**
        1.  **type**: يجب أن تكون "SIMILAR".
        2.  **similarProjectInfo**: كائن يحتوي على "name", "status", "course", "creationDate", و "link" للمشروع المشابه (استخدم البيانات المعطاة بالضبط).
        3.  **summary**: ملخص من فقرة واحدة عن هدف المشروع المشابه.
        4.  **matchPercentage**: مصفوفة من 4 كائنات بالضبط. كل كائن يجب أن يحتوي على "aspect" (واحد من: "الهدف العام", "الفئة المستهدفة", "التقنية المستخدمة", "المخرجات المتوقعة") و "percentage" (رقم واقعي بين 25 و 69).
        5.  **detailedComparison**: مصفوفة من 4-5 عناصر مقارنة رئيسية. لكل عنصر، قم **باستخلاص واقتباس الجمل أو النقاط الرئيسية** من "فكرة المستخدم" ومن "وصف المشروع المشابه" وضعها في حقلي "yourIdea" و "matchedIdea". **لا تترك هذه الحقول فارغة.**
        6.  **recommendations**: مصفوفة من 4 توصيات عملية وقابلة للتنفيذ. كل توصية يجب أن تحتوي على "id" (من 1 إلى 4)، "suggestion" (عنوان قصير)، و "details" (شرح من جملة واحدة).
    `;
    const result = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
    });
    return JSON.parse(result.text.trim());
};

/**
 * ⚠️ Agent 2B: Duplicate Idea Reporter
 */
export const generateDuplicateIdeaReport = async (
    userIdea: string,
    matchedIdea: StoredIdea
): Promise<DuplicateIdeaReport> => {
    const prompt = `
      أنت خبير في ضمان الجودة الأكاديمية. تم تصنيف فكرة المستخدم على أنها "مكررة" لمشروع موجود. مهمتك هي إنشاء تقرير تحليلي مفصل يثبت هذا التكرار وينتهي بتحذير واضح.

      **فكرة المستخدم:**
      "${userIdea}"

      **المشروع المكرر:**
      - العنوان: "${matchedIdea.title}"
      - المقرر: ${matchedIdea.course}
      - الحالة: ${matchedIdea.status}
      - تاريخ الإنشاء: ${matchedIdea.creationDate}
      - وصف المشكلة: ${matchedIdea.problemDescription}
      - الحل المقترح: ${matchedIdea.proposedSolution}
      - الرابط: ${matchedIdea.link || 'لا يوجد'}

      **المخرج المطلوب (JSON باللغة العربية):**
      1.  **type**: يجب أن تكون "DUPLICATE".
      2.  **duplicateProjectInfo**: كائن يحتوي على "name", "status", "course", "creationDate", و "link" للمشروع المكرر (استخدم البيانات المعطاة بالضبط).
      3.  **summary**: ملخص من فقرة واحدة عن هدف المشروع المكرر.
      4.  **matchPercentage**: مصفوفة من 4 كائنات بالضبط. كل كائن يجب أن يحتوي على "aspect" (واحد من: "الهدف العام", "الفئة المستهدفة", "التقنية المستخدمة", "المخرجات المتوقعة") و "percentage" (رقم واقعي وعالٍ جدًا بين 70 و 100). قم بحساب نسبة دقيقة لكل جانب بناءً على التحليل.
      5.  **detailedComparison**: مصفوفة من 4-5 عناصر مقارنة رئيسية. لكل عنصر، قم **باستخلاص واقتباس الجمل أو النقاط الرئيسية المتطابقة** من "فكرة المستخدم" ومن "وصف المشروع المكرر" وضعها في حقلي "yourIdea" و "matchedIdea". **يجب أن تكون النصوص هنا متشابهة جدًا لإثبات التكرار. لا تترك هذه الحقول فارغة.**
        مثال: 
        {
          "element": "المشكلة الأساسية",
          "yourIdea": "يواجه المزارعون صعوبة في تحديد أمراض النباتات بسرعة.",
          "matchedIdea": "صعوبة تشخيص أمراض المحاصيل الزراعية بشكل فوري ودقيق."
        }
      6.  **finalWarning**: كائن يحتوي على "title" (مثال: "تنبيه: الفكرة مكررة بالكامل") و "details" (مصفوفة من 2-3 جمل تشرح الخطوات التالية).
    `;
     const result = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: {
            responseMimeType: "application/json",
        }
    });
    return JSON.parse(result.text.trim());
};

/**
 * 🎨 Agent 3: Visual Inspiration Generator
 */
export const generateVisualInspirationBrief = async (idea: string): Promise<VisualInspirationBrief> => {
  const briefPrompt = `
    A user has a UNIQUE project idea. Act as a creative director and generate a visual identity brief in Arabic.
    User's Idea: "${idea}"

    Generate a JSON object in Arabic with the following structure:
    1.  "type": "UNIQUE"
    2.  "projectSummary": "ملخص قصير وجذاب للمشروع في فقرة واحدة."
    3.  "visualIdentity": {
        "logoSuggestion": "وصف موجز ومبتكر لاقتراح الشعار.",
        "colorPalette": "وصف للوحة الألوان المقترحة (مثال: أزرق سماوي، أبيض، رمادي فاتح).",
        "iconStyle": "وصف لنمط الأيقونات المقترح (مثال: خطية بسيطة - Line Icons).",
        "fontSuggestion": "اقتراح لزوج من الخطوط (مثال: Noto Sans للعناوين / Open Sans للنصوص)."
    }
    4.  "designDirections": An array of 3 objects, each with "name" and "description" for a design direction (e.g., Minimal, Clean Educational, Gamified).
    5.  "inspirationLinks": An array of 3 objects, one for Dribbble, one for Behance, and one for Figma Community. Each must have "site" and "url". The URL must be a specific search query based on the idea.
  `;

  const result = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: briefPrompt,
    config: {
        responseMimeType: "application/json",
    },
  });

  return JSON.parse(result.text.trim());
};

/**
 * ✨ Agent 4: Development Assistant
 */
export const generateDevelopmentSuggestion = async (
    idea: string,
    requestType: 'features' | 'tech-stack' | 'user-persona' | 'user-stories'
): Promise<string> => {

    let instruction = '';
    switch (requestType) {
        case 'features':
            instruction = 'اقترح قائمة بالميزات الأساسية (Minimum Viable Product) وقائمة بالميزات المستقبلية لهذا المشروع. قدمها كنقاط markdown.';
            break;
        case 'tech-stack':
            instruction = 'ما هي أفضل حزمة تقنيات (Tech Stack) لبناء هذا المشروع (واجهة أمامية، خلفية، قاعدة بيانات)؟ اشرح سبب كل اختيار في جملة واحدة.';
            break;
        case 'user-persona':
            instruction = 'أنشئ شخصية مستخدم (User Persona) مفصلة للفئة المستهدفة من هذا المشروع. يجب أن تتضمن الاسم، العمر، الأهداف، والتحديات.';
            break;
        case 'user-stories':
            instruction = 'اكتب 3-5 قصص مستخدم (User Stories) مهمة لهذا المشروع بصيغة Agile القياسية (بصفتي...، أريد أن...، لكي...).';
            break;
    }

    const prompt = `
        أنت "مساعد تطوير مشاريع ذكي". مهمتك هي مساعدة المستخدم على تحويل فكرته إلى خطة عمل.
        
        **فكرة المشروع:**
        "${idea}"

        **المهمة المطلوبة:**
        ${instruction}

        الرد يجب أن يكون باللغة العربية، ومنسقًا بشكل جيد باستخدام Markdown.
    `;
    
    const result = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
    });
    
    return result.text;
};