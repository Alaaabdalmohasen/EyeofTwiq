import React, { useState } from 'react';
import { ProjectIdea, VisualInspirationBrief } from '../types';
import { generateDevelopmentSuggestion } from '../services/geminiService';
import { SparklesIcon, TagIcon, SwatchIcon, SquaresIcon, TypeIcon } from './Icons';

interface ProjectWorkspaceProps {
    idea: ProjectIdea;
    inspiration: VisualInspirationBrief | null;
    onBack: () => void;
}

type SuggestionType = 'features' | 'tech-stack' | 'user-persona' | 'user-stories';
type SuggestionData = {
    title: string;
    content: string;
    type: SuggestionType;
};

const InfoCard: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
    <div className="bg-gray-900/60 p-3 rounded-lg border border-gray-700 flex items-center gap-3">
        <div className="text-purple-400">{icon}</div>
        <div>
            <p className="text-xs text-gray-400">{label}</p>
            <p className="font-semibold text-sm text-gray-200">{value}</p>
        </div>
    </div>
);

const ProjectWorkspace: React.FC<ProjectWorkspaceProps> = ({ idea, inspiration, onBack }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [suggestion, setSuggestion] = useState<SuggestionData | null>(null);

    const downloadAsFile = (content: string, filename: string) => {
        const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleSuggestionRequest = async (type: SuggestionType, title: string) => {
        setIsLoading(true);
        setSuggestion(null);
        try {
            const fullIdeaDescription = `اسم المشروع: ${idea.projectName}\nوصف المشكلة: ${idea.problemDescription}\nالحل المقترح: ${idea.solution}`;
            const response = await generateDevelopmentSuggestion(fullIdeaDescription, type);
            setSuggestion({ title, content: response, type });
        } catch (error) {
            console.error("Failed to get suggestion:", error);
            setSuggestion({ title: "خطأ", content: "فشل في الحصول على الاقتراح.", type });
        } finally {
            setIsLoading(false);
        }
    };
    
    const suggestionButtons: { type: SuggestionType; label: string; title: string }[] = [
        { type: 'features', label: 'اقتراح الميزات', title: 'قائمة الميزات المقترحة (MVP)' },
        { type: 'tech-stack', label: 'اقتراح التقنيات', title: 'حزمة التقنيات المقترحة (Tech Stack)' },
        { type: 'user-persona', label: 'إنشاء شخصية المستخدم', title: 'شخصية المستخدم (User Persona)' },
        { type: 'user-stories', label: 'كتابة قصص المستخدم', title: 'قصص المستخدم (User Stories)' },
    ];

    return (
        <div className="space-y-8">
            <header className="text-center">
                <h2 className="text-3xl font-bold text-gray-100">لوحة عمل المشروع: {idea.projectName}</h2>
                <p className="text-lg text-gray-400 mt-2">حوّل فكرتك إلى خطة عمل حقيقية بمساعدة الذكاء الاصطناعي.</p>
            </header>

            {inspiration && (
                 <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                    <h4 className="text-lg font-semibold mb-4 text-purple-300">الهوية البصرية المقترحة</h4>
                     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <InfoCard icon={<TagIcon className="w-5 h-5"/>} label="اقتراح الشعار" value={inspiration.visualIdentity.logoSuggestion} />
                        <InfoCard icon={<SwatchIcon className="w-5 h-5"/>} label="لوحة الألوان" value={inspiration.visualIdentity.colorPalette} />
                        <InfoCard icon={<SquaresIcon className="w-5 h-5"/>} label="نمط الأيقونات" value={inspiration.visualIdentity.iconStyle} />
                        <InfoCard icon={<TypeIcon className="w-5 h-5"/>} label="الخط المقترح" value={inspiration.visualIdentity.fontSuggestion} />
                    </div>
                </div>
            )}

            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold mb-4 text-purple-300">مساعد التطوير الذكي</h3>
                <p className="text-sm text-gray-400 mb-4">اطلب المساعدة من الوكيل الذكي لتخطيط مشروعك.</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {suggestionButtons.map(({ type, label, title }) => (
                         <button key={type} onClick={() => handleSuggestionRequest(type, title)} disabled={isLoading}
                                 className="px-4 py-2 text-sm font-semibold text-white bg-purple-700 rounded-lg hover:bg-purple-600 disabled:bg-gray-600 transition-colors">
                            {label}
                        </button>
                    ))}
                </div>
            </div>

            {(isLoading || suggestion) && (
                <div className="p-5 bg-black/30 rounded-lg border border-gray-700 min-h-[200px] flex items-center justify-center">
                    {isLoading ? (
                        <div className="flex flex-col items-center gap-2 text-gray-400">
                             <svg className="animate-spin h-8 w-8 text-purple-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            <span>المساعد الذكي يعمل...</span>
                        </div>
                    ) : (
                        suggestion && (
                             <div className="prose prose-invert prose-p:text-gray-300 prose-headings:text-purple-300 prose-ul:text-gray-300 prose-strong:text-white w-full">
                                <div className="flex justify-between items-center mb-4">
                                    <h3 className="m-0">{suggestion.title}</h3>
                                    <button 
                                        onClick={() => downloadAsFile(suggestion.content, `${suggestion.type.replace('-', '_')}_suggestion.txt`)}
                                        className="px-3 py-1 text-xs font-semibold text-purple-200 bg-purple-800 rounded-md hover:bg-purple-700 transition-colors"
                                    >
                                        حفظ كملف
                                    </button>
                                </div>
                                <div dangerouslySetInnerHTML={{ __html: suggestion.content.replace(/\n/g, '<br />') }} />
                             </div>
                        )
                    )}
                </div>
            )}
             <div className="text-center mt-8">
                <button onClick={onBack} className="px-8 py-2 font-semibold text-purple-200 bg-transparent border border-purple-500 rounded-lg hover:bg-purple-500/20 transition-colors">
                    العودة
                </button>
             </div>
        </div>
    );
};

export default ProjectWorkspace;