import React from 'react';
import { AnalysisReport, DuplicateIdeaReport, SimilarIdeaReport, VisualInspirationBrief } from '../types';
import { 
    SparklesIcon, LightBulbIcon, PencilIcon, ClockIcon, CalendarIcon, BookOpenIcon, 
    ExclamationCircleIcon, DocumentDuplicateIcon, TagIcon, SwatchIcon, SquaresIcon, TypeIcon, LinkIcon
} from './Icons';

interface ResultDisplayProps {
    isLoading: boolean;
    report: AnalysisReport | null;
    onReset: () => void;
}

const classificationStyles: Record<string, { bg: string, text: string, border: string, title: string, icon: React.ReactElement }> = {
    UNIQUE: { bg: 'bg-green-900/50', text: 'text-green-300', border: 'border-green-500/50', title: 'تحليل فكرة فريدة', icon: <SparklesIcon className="w-8 h-8"/> },
    SIMILAR: { bg: 'bg-yellow-900/50', text: 'text-yellow-300', border: 'border-yellow-500/50', title: 'تحليل التشابه الدلالي لمشروعك', icon: <LightBulbIcon className="w-8 h-8"/> },
    DUPLICATE: { bg: 'bg-red-900/50', text: 'text-red-300', border: 'border-red-500/50', title: 'تحليل التشابه الدلالي لمشروعك', icon: <DocumentDuplicateIcon className="w-8 h-8"/> },
};

const InfoCard: React.FC<{ icon: React.ReactNode; label: string; value: string; href?: string }> = ({ icon, label, value, href }) => {
    const content = (
         <div className="bg-gray-900/60 p-3 h-full rounded-lg border border-gray-700 flex items-center gap-3">
            <div className="text-purple-400">{icon}</div>
            <div>
                <p className="text-xs text-gray-400">{label}</p>
                <p className="font-semibold text-sm text-gray-200 break-all">{value}</p>
            </div>
        </div>
    );

    if (href) {
        return (
            <a href={href} target="_blank" rel="noopener noreferrer" className="block hover:bg-gray-800 transition-colors rounded-lg">
                {content}
            </a>
        )
    }
    return content;
};

const ProgressCircle: React.FC<{ percentage: number; label: string }> = ({ percentage, label }) => {
    const circumference = 2 * Math.PI * 45;
    const offset = circumference - (percentage / 100) * circumference;

    return (
        <div className="flex items-center justify-between p-2 bg-gray-800 rounded-lg">
             <div className="relative w-16 h-16">
                <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle className="text-gray-700" strokeWidth="8" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
                    <circle
                        className="text-purple-500"
                        strokeWidth="8"
                        strokeDasharray={circumference}
                        strokeDashoffset={offset}
                        strokeLinecap="round"
                        stroke="currentColor"
                        fill="transparent"
                        r="45"
                        cx="50"
                        cy="50"
                        style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
                        transform="rotate(-90 50 50)"
                    />
                    <text x="50" y="52" className="text-xl font-bold fill-current text-gray-200" textAnchor="middle" dominantBaseline="middle">
                        {percentage}%
                    </text>
                </svg>
            </div>
            <span className="font-medium text-gray-300 text-sm flex-1 text-center">{label}</span>
        </div>
    );
};

const renderSimilarOrDuplicateReport = (report: SimilarIdeaReport | DuplicateIdeaReport, onReset: () => void) => {
    const isDuplicate = report.type === 'DUPLICATE';
    const projectInfo = isDuplicate ? (report as DuplicateIdeaReport).duplicateProjectInfo : (report as SimilarIdeaReport).similarProjectInfo;
    const recommendations = !isDuplicate ? (report as SimilarIdeaReport).recommendations : null;
    const finalWarning = isDuplicate ? (report as DuplicateIdeaReport).finalWarning : null;

    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <InfoCard icon={<PencilIcon className="w-5 h-5"/>} label="اسم المشروع" value={projectInfo.name} />
                <InfoCard icon={<ClockIcon className="w-5 h-5"/>} label="الحالة" value={projectInfo.status} />
                <InfoCard icon={<CalendarIcon className="w-5 h-5"/>} label="تاريخ الإنشاء" value={projectInfo.creationDate} />
                <InfoCard icon={<BookOpenIcon className="w-5 h-5"/>} label="المقرر" value={projectInfo.course} />
                {projectInfo.link && (
                    <div className="lg:col-span-2">
                        <InfoCard 
                            icon={<LinkIcon className="w-5 h-5"/>} 
                            label="رابط المشروع" 
                            value={projectInfo.link} 
                            href={projectInfo.link}
                        />
                    </div>
                )}
            </div>

            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold mb-2 text-purple-300">ملخص المشروع المشابه</h3>
                <p className="text-gray-300">{report.summary}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                    <h3 className="text-lg font-semibold mb-4 text-purple-300">تحليل التشابه التفصيلي</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-300">
                            <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                                <tr>
                                    <th scope="col" className="px-4 py-3">العنصر</th>
                                    <th scope="col" className="px-4 py-3">فكرتك</th>
                                    <th scope="col" className="px-4 py-3">المشروع المشابه</th>
                                </tr>
                            </thead>
                            <tbody>
                                {report.detailedComparison.map((item, index) => (
                                    <tr key={index} className="border-b border-gray-700 hover:bg-gray-800/50">
                                        <th scope="row" className="px-4 py-3 font-medium whitespace-nowrap">{item.element}</th>
                                        <td className="px-4 py-3">{item.yourIdea}</td>
                                        <td className="px-4 py-3">{item.matchedIdea}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                     <p className="text-xs text-gray-500 mt-3">* تم تحديد التشابه بناءً على التحليل الدلالي للمحتوى، وليس فقط على تطابق النصوص.</p>
                </div>
                <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                    <h3 className="text-lg font-semibold mb-4 text-purple-300">نسبة التطابق</h3>
                    <div className="space-y-3">
                        {report.matchPercentage.map((item, index) => (
                            <ProgressCircle key={index} percentage={item.percentage} label={item.aspect} />
                        ))}
                    </div>
                </div>
            </div>

            {recommendations && (
                <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                    <h3 className="text-lg font-semibold mb-4 text-purple-300">توصيات التطوير الذكي</h3>
                    <div className="space-y-4">
                        {recommendations.map(rec => (
                            <div key={rec.id} className="flex items-start gap-4">
                                <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-purple-800 text-purple-200 rounded-full font-bold">{rec.id}</div>
                                <div>
                                    <h4 className="font-semibold text-gray-200">{rec.suggestion}</h4>
                                    <p className="text-gray-400">{rec.details}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            {finalWarning && (
                <div className="p-5 bg-red-900/30 rounded-lg border border-red-700">
                    <div className="flex items-center gap-3 mb-3">
                        <ExclamationCircleIcon className="w-6 h-6 text-red-400"/>
                        <h3 className="text-lg font-semibold text-red-300">{finalWarning.title}</h3>
                    </div>
                    <ul className="list-disc list-inside space-y-2 text-red-300/90">
                       {finalWarning.details.map((detail, index) => <li key={index}>{detail}</li>)}
                    </ul>
                </div>
            )}

            <div className="text-center mt-8 flex justify-center gap-4">
                <button onClick={() => window.print()} className="px-8 py-2 font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-500 transition-colors">
                    طباعة التقرير
                </button>
                 <button onClick={onReset} className="px-8 py-2 font-semibold text-purple-200 bg-transparent border border-purple-500 rounded-lg hover:bg-purple-500/20 transition-colors">
                    تحليل فكرة جديدة
                </button>
            </div>
        </div>
    );
};

const renderUniqueReport = (report: VisualInspirationBrief, onReset: () => void) => {
    const { visualIdentity } = report;
    return (
        <div className="space-y-8">
            <header className="text-center">
                <h3 className="text-3xl font-bold text-gray-100">دعنا نحوّل فكرتك إلى تجربة بصرية مميزة</h3>
                <p className="text-lg text-gray-400 mt-2">تعكس هدف مشروعك</p>
            </header>
            
            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h4 className="text-lg font-semibold mb-4 text-purple-300">اقترح الوكيل الذكي هوية بصرية أولية لمشروعك:</h4>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <InfoCard icon={<TagIcon className="w-5 h-5"/>} label="اقتراح الشعار" value={visualIdentity.logoSuggestion} />
                    <InfoCard icon={<SwatchIcon className="w-5 h-5"/>} label="لوحة الألوان" value={visualIdentity.colorPalette} />
                    <InfoCard icon={<SquaresIcon className="w-5 h-5"/>} label="نمط الأيقونات" value={visualIdentity.iconStyle} />
                    <InfoCard icon={<TypeIcon className="w-5 h-5"/>} label="الخط المقترح" value={visualIdentity.fontSuggestion} />
                </div>
            </div>
            
            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold mb-2 text-purple-300">ملخص المشروع</h3>
                <p className="text-gray-300">{report.projectSummary}</p>
            </div>

            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold mb-4 text-purple-300">مساعد الإلهام المرئي</h3>
                 <p className="text-sm text-gray-400 mb-4">فكرتك تدور حول التعليم وتحسين تجربة المستخدم. إليك ثلاثة اتجاهات تصميمية مناسبة يمكنك البدء منها:</p>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-300">
                         <thead className="text-xs text-gray-400 uppercase bg-gray-800">
                            <tr>
                                <th scope="col" className="px-4 py-3">الاتجاهات التصميمية</th>
                                <th scope="col" className="px-4 py-3">الوصف</th>
                            </tr>
                        </thead>
                        <tbody>
                            {report.designDirections.map((item, index) => (
                                <tr key={index} className="border-b border-gray-700 hover:bg-gray-800/50">
                                    <th scope="row" className="px-4 py-3 font-medium whitespace-nowrap">{item.name}</th>
                                    <td className="px-4 py-3">{item.description}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div className="p-5 bg-gray-900/60 rounded-lg border border-gray-700">
                <h3 className="text-lg font-semibold mb-4 text-purple-300">روابط إلهام خارجية</h3>
                <p className="text-sm text-gray-400 mb-4">يمكنك الاطلاع على مشاريع مشابهة لتستلهم منها نمط التصميم المناسب:</p>
                <div className="space-y-4">
                    {report.inspirationLinks.map((link, index) => (
                        <a href={link.url} target="_blank" rel="noopener noreferrer" key={link.site} 
                           className="flex items-center justify-between p-4 bg-gray-800 rounded-lg hover:bg-gray-700/80 transition-all duration-300 border-b-2 border-transparent hover:border-purple-500">
                            <span className="font-semibold text-purple-300">{link.site}</span>
                            <div className="flex-shrink-0 w-8 h-8 flex items-center justify-center bg-gray-700 text-gray-300 rounded-full font-bold">{index + 1}</div>
                        </a>
                    ))}
                </div>
                 <p className="text-xs text-gray-500 mt-4">* استفد من هذه التصاميم كنقطة انطلاق، ثم أضف لمستك الخاصة. الذكاء يصنع البداية... والإبداع يصنع الفرق.</p>
            </div>
            
             <div className="text-center mt-8 flex justify-center gap-4">
                <button onClick={() => window.print()} className="px-8 py-2 font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-500 transition-colors">
                    طباعة التقرير
                </button>
                 <button onClick={onReset} className="px-8 py-2 font-semibold text-purple-200 bg-transparent border border-purple-500 rounded-lg hover:bg-purple-500/20 transition-colors">
                    تحليل فكرة جديدة
                </button>
            </div>

        </div>
    );
};


const ResultDisplay: React.FC<ResultDisplayProps> = ({ isLoading, report, onReset }) => {
    if (isLoading && !report) {
        return (
            <div className="text-center py-10">
                <p className="text-lg text-gray-400">يقوم الوكلاء بتحليل فكرتك... قد يستغرق هذا بعض الوقت.</p>
            </div>
        );
    }

    if (!report) {
        return null;
    }

    const style = classificationStyles[report.type];

    const renderContent = () => {
        switch (report.type) {
            case 'SIMILAR':
            case 'DUPLICATE':
                return renderSimilarOrDuplicateReport(report, onReset);
            case 'UNIQUE':
                return renderUniqueReport(report, onReset);
            default:
                return <p>نوع تقرير غير معروف.</p>;
        }
    };
    
    return (
        <div className="mt-8">
            <header className={`p-6 rounded-t-lg flex items-center gap-4 ${style.bg} border-b-2 ${style.border}`}>
                {style.icon}
                <h2 className={`text-3xl font-bold ${style.text}`}>{style.title}</h2>
            </header>
            <div className="p-6 md:p-8 bg-black/30 rounded-b-lg">
                {renderContent()}
            </div>
        </div>
    );
};

export default ResultDisplay;