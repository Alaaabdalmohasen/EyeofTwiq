import React, { useState } from 'react';
import { StoredIdea } from '../types';

interface ContactFormProps {
    matchedIdea: StoredIdea | null;
    onBack: () => void;
}

const inputStyles = "w-full p-3 bg-gray-800 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-shadow duration-300 text-gray-200 placeholder-gray-500";

const ContactForm: React.FC<ContactFormProps> = ({ matchedIdea, onBack }) => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        projectName: '',
        email: '',
        phone: '',
        message: `مرحبًا فريق مشروع "${matchedIdea?.title}",\n\nلقد قمت بتطوير فكرة مشروع مشابهة لمشروعكم وأود مناقشة إمكانية دمج جهودنا. هل يمكننا تحديد موعد للتحدث؟\n\nشكرًا لكم.`
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!matchedIdea?.contactEmail) {
            alert('لا يوجد بريد إلكتروني للتواصل مع هذا الفريق.');
            return;
        }

        const subject = `اقتراح دمج مشروع: ${formData.projectName} مع ${matchedIdea.title}`;
        const body = encodeURIComponent(formData.message);
        window.location.href = `mailto:${matchedIdea.contactEmail}?subject=${encodeURIComponent(subject)}&body=${body}`;
    };

    return (
        <div className="flex flex-col items-center">
            <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text mb-8">
                تواصل مع الفريق الآخر
            </h2>
            <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-8 items-center bg-gray-900/50 p-8 rounded-2xl border border-gray-700">
                <div className="text-center lg:text-right">
                    <img src="https://storage.googleapis.com/aai-web-template-files/190823c3-9831-4043-9878-a006c8b9b8b0.png" alt="Collaboration" className="w-full max-w-sm mx-auto rounded-lg"/>
                </div>
                <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
                    <div>
                        <h3 className="text-2xl font-semibold mb-1 text-gray-100">اقتراح دمج مشروعين</h3>
                        <p className="text-gray-400">أرسل طلبك للتواصل مع الفريق الآخر لبحث الدمج وتوحيد الجهود.</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <input type="text" name="firstName" placeholder="الاسم الأول" value={formData.firstName} onChange={handleInputChange} className={inputStyles} required />
                        <input type="text" name="lastName" placeholder="الاسم الأخير" value={formData.lastName} onChange={handleInputChange} className={inputStyles} required />
                    </div>
                    <input type="text" name="projectName" placeholder="اسم المشروع" value={formData.projectName} onChange={handleInputChange} className={inputStyles} required />
                    <input type="email" name="email" placeholder="البريد الالكتروني" value={formData.email} onChange={handleInputChange} className={inputStyles} required />
                    <input type="tel" name="phone" placeholder="رقم الجوال" value={formData.phone} onChange={handleInputChange} className={inputStyles} />
                    <textarea name="message" rows={5} placeholder="الرسالة" value={formData.message} onChange={handleInputChange} className={inputStyles} required></textarea>
                     <div className="flex gap-4">
                        <button type="button" onClick={onBack} className="w-full px-6 py-3 font-semibold text-white bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors">
                            رجوع
                        </button>
                        <button type="submit" className="w-full px-6 py-3 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-500 hover:to-blue-500 transition-all">
                            إرسال
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ContactForm;
