import React from 'react';
import { SparklesIcon, PlusCircleIcon } from './Icons';
import { ProjectIdea, Course } from '../types';

interface IdeaInputFormProps {
    idea: ProjectIdea;
    setIdea: (idea: ProjectIdea) => void;
    onSubmit: () => void;
    isLoading: boolean;
    courses: Course[];
    fieldsList: string[];
    technologiesList: string[];
}

const inputStyles = "w-full p-3 bg-gray-900 border border-gray-600 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-shadow duration-300 text-gray-200 placeholder-gray-500";
const labelStyles = "block text-md font-medium text-gray-300 mb-2";

const IdeaInputForm: React.FC<IdeaInputFormProps> = ({ idea, setIdea, onSubmit, isLoading, courses, fieldsList, technologiesList }) => {
    
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setIdea({ ...idea, [name]: value });
    };

    const handleMemberChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const newMembers = [...idea.members];
        const member = newMembers[index];
        if (name === 'name' || name === 'email') {
            member[name] = value;
        }
        setIdea({ ...idea, members: newMembers });
    };

    const addMember = () => {
        setIdea({ ...idea, members: [...idea.members, { name: '', email: '' }] });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit();
    };

    return (
        <form onSubmit={handleSubmit} className="flex flex-col gap-8">
            <h2 className="text-2xl font-bold text-center text-gray-100">نموذج تسجيل الفكرة</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="projectName" className={labelStyles}>اسم المشروع*</label>
                    <input type="text" id="projectName" name="projectName" value={idea.projectName} onChange={handleInputChange} className={inputStyles} required />
                </div>
                 <div>
                    <label htmlFor="course" className={labelStyles}>اختر المقرر*</label>
                    <select
                        id="course"
                        name="course"
                        value={idea.course}
                        onChange={handleInputChange}
                        className={inputStyles}
                        required
                    >
                        {courses.map((course) => (
                            <option key={course.name} value={course.name}>
                                {course.name}
                            </option>
                        ))}
                    </select>
                </div>
                 <div>
                    <label htmlFor="field" className={labelStyles}>مجال الفكرة*</label>
                    <select id="field" name="field" value={idea.field} onChange={handleInputChange} className={inputStyles} required>
                         {fieldsList.map((field) => (
                            <option key={field} value={field}>
                                {field}
                            </option>
                        ))}
                    </select>
                </div>
                 <div>
                    <label htmlFor="technologies" className={labelStyles}>التقنيات المستخدمة*</label>
                     <select id="technologies" name="technologies" value={idea.technologies} onChange={handleInputChange} className={inputStyles} required>
                         {technologiesList.map((tech) => (
                            <option key={tech} value={tech}>
                                {tech}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            <div>
                <label htmlFor="problemDescription" className={labelStyles}>وصف المشكلة التي تحاول حلها، صفها لنا بالتفصيل*</label>
                <textarea id="problemDescription" name="problemDescription" rows={4} value={idea.problemDescription} onChange={handleInputChange} className={inputStyles} required />
            </div>
            
            <div>
                <label htmlFor="solution" className={labelStyles}>الحل المقترح*</label>
                <textarea id="solution" name="solution" rows={4} value={idea.solution} onChange={handleInputChange} className={inputStyles} required />
            </div>

            <div>
                <label htmlFor="impact" className={labelStyles}>الأثر المحتمل*</label>
                <textarea id="impact" name="impact" rows={4} value={idea.impact} onChange={handleInputChange} className={inputStyles} required />
            </div>

             <div>
                <label htmlFor="targetAudience" className={labelStyles}>الفئة المستهدفة*</label>
                <textarea id="targetAudience" name="targetAudience" rows={4} value={idea.targetAudience} onChange={handleInputChange} className={inputStyles} required />
            </div>
            
            <div>
                <h3 className="text-xl font-semibold mb-4 text-gray-200">أعضاء الفريق</h3>
                <div className="space-y-4">
                    {idea.members.map((member, index) => (
                        <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-gray-900 rounded-lg border border-gray-700">
                             <div>
                                <label htmlFor={`memberName-${index}`} className="block text-sm font-medium text-gray-400 mb-1">الاسم الأول*</label>
                                <input type="text" id={`memberName-${index}`} name="name" value={member.name} onChange={(e) => handleMemberChange(index, e)} className={inputStyles} required />
                            </div>
                            <div>
                                <label htmlFor={`memberEmail-${index}`} className="block text-sm font-medium text-gray-400 mb-1">البريد الإلكتروني*</label>
                                <input type="email" id={`memberEmail-${index}`} name="email" value={member.email} onChange={(e) => handleMemberChange(index, e)} className={inputStyles} required />
                            </div>
                        </div>
                    ))}
                </div>
                <button type="button" onClick={addMember} className="mt-4 flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors">
                    <PlusCircleIcon className="w-6 h-6" />
                    <span>إضافة عضو آخر</span>
                </button>
            </div>


            <button
                type="submit"
                disabled={isLoading}
                className="self-center flex items-center justify-center gap-2 px-12 py-4 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-500 hover:to-blue-500 disabled:bg-gray-600 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-purple-500 text-lg"
            >
                {isLoading ? (
                    <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        يتم التحليل...
                    </>
                ) : (
                    <>
                        <SparklesIcon className="w-5 h-5" />
                        تسجيل الفكرة والتحليل
                    </>
                )}
            </button>
        </form>
    );
};

export default IdeaInputForm;