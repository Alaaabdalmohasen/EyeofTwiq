import React from 'react';
import { AgentStatus } from '../types';
import { CheckCircleIcon, CubeIcon, ExclamationCircleIcon, LightBulbIcon, DocumentDuplicateIcon } from './Icons';

const statusConfig: Record<AgentStatus, { color: string; icon: React.ReactElement }> = {
    idle: { color: 'text-gray-500', icon: <CubeIcon className="w-5 h-5" /> },
    running: { color: 'text-yellow-400', icon: (
        <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
    )},
    completed: { color: 'text-green-400', icon: <CheckCircleIcon className="w-5 h-5" /> },
    error: { color: 'text-red-400', icon: <ExclamationCircleIcon className="w-5 h-5" /> },
};

const agentIcons: Record<string, React.ReactElement> = {
    'التحليل المبدئي': <LightBulbIcon className="w-6 h-6 ml-3 text-purple-400"/>,
    'إنشاء التقرير التفصيلي': <DocumentDuplicateIcon className="w-6 h-6 ml-3 text-cyan-400"/>,
};

interface AgentPipelineProps {
    statuses: Record<string, AgentStatus>;
}

const AgentPipeline: React.FC<AgentPipelineProps> = ({ statuses }) => {
    return (
        <div>
            <h2 className="text-xl font-semibold mb-4 text-gray-300">حالة الوكلاء</h2>
            <div className="space-y-3">
                {Object.entries(statuses).map(([name, status]) => (
                    <div key={name} className="flex items-center p-3 bg-gray-900/70 rounded-lg border border-gray-700">
                        {agentIcons[name] || <CubeIcon className="w-6 h-6 ml-3 text-gray-400"/>}
                        <span className="flex-grow font-medium text-gray-200">{name}</span>
                        <div className={`flex items-center gap-2 ${statusConfig[status].color}`}>
                            {statusConfig[status].icon}
                            <span className="capitalize text-sm font-semibold">{status}</span>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AgentPipeline;