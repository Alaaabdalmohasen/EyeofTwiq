export type Step = 'input' | 'summary' | 'report' | 'contact' | 'workspace';

export enum IdeaClassification {
    UNIQUE = 'UNIQUE',
    SIMILAR = 'SIMILAR',
    DUPLICATE = 'DUPLICATE',
}

export interface InitialAnalysisResult {
    classification: IdeaClassification;
    justification: string;
    similarToIndex: number | null;
    similarityPercentage: number;
    matchedProjectName: string | null;
    matchedProjectCourse: string | null;
    matchedProjectLink: string | null;
}

export type AgentStatus = 'idle' | 'running' | 'completed' | 'error';

// Base type for stored project ideas, now more detailed
export interface StoredIdea {
    title: string;
    course: string;
    status: string;
    creationDate: string;
    problemDescription: string;
    proposedSolution: string;
    potentialImpact: string;
    domain: string;
    targetAudience: string;
    link?: string;
    contactEmail?: string;
}

// Data structure for a Course
export interface Course {
    name: string;
    objectives: string[];
    outcomes: string[];
}

// Data structure for the context sent to the AI
export interface CourseContext {
    name: string;
    objectives: string[];
    outcomes: string[];
}


// Unified structure for detailed reports
interface BaseDetailedReport {
    summary: string;
    matchPercentage: Array<{
        aspect: string;
        percentage: number;
    }>;
    detailedComparison: Array<{
        element: string;
        yourIdea: string;
        matchedIdea: string;
    }>;
}

export interface SimilarIdeaReport extends BaseDetailedReport {
    type: 'SIMILAR';
    similarProjectInfo: {
        name: string;
        status: string;
        course: string;
        creationDate: string;
        link?: string;
    };
    recommendations: Array<{
        id: number;
        suggestion: string;
        details: string;
    }>;
}

export interface DuplicateIdeaReport extends BaseDetailedReport {
    type: 'DUPLICATE';
    duplicateProjectInfo: {
        name: string;
        status: string;
        course: string;
        creationDate: string;
        link?: string;
    };
    finalWarning: {
        title: string;
        details: string[];
    };
}

export interface VisualInspirationBrief {
  type: 'UNIQUE';
  projectSummary: string;
  visualIdentity: {
    logoSuggestion: string;
    colorPalette: string;
    iconStyle: string;
    fontSuggestion: string;
  };
  designDirections: Array<{
    name: string;
    description: string;
  }>;
  inspirationLinks: Array<{
    site: string;
    url: string;
  }>;
}


export interface TeamMember {
    name: string;
    email: string;
}

export interface ProjectIdea {
    projectName: string;
    course: string;
    field: string;
    technologies: string;
    problemDescription: string;
    solution: string;
    impact: string;
    targetAudience: string;
    members: TeamMember[];
}


export type AnalysisReport = SimilarIdeaReport | DuplicateIdeaReport | VisualInspirationBrief;