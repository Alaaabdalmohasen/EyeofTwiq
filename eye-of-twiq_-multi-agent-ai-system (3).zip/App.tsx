import React, { useState, useCallback, useEffect } from 'react';
import { AgentStatus, AnalysisReport, ProjectIdea, StoredIdea, InitialAnalysisResult, CourseContext, Step, VisualInspirationBrief } from './types';
import { EXISTING_IDEAS, COURSES_DATA, FIELDS_LIST, TECHNOLOGIES_LIST } from './constants';
import IdeaInputForm from './components/IdeaInputForm';
import AgentPipeline from './components/AgentPipeline';
import ResultDisplay from './components/ResultDisplay';
import { EyeIcon } from './components/Icons';
import { analyzeIdeaSimilarity, generateSimilarIdeaReport, generateDuplicateIdeaReport, generateVisualInspirationBrief } from './services/geminiService';
import AnalysisSummary from './components/AnalysisSummary';
import ContactForm from './components/ContactForm';
import ProjectWorkspace from './components/ProjectWorkspace';

const LOCAL_STORAGE_KEY = 'eye-of-twiq-ideas';

const serializeIdea = (idea: ProjectIdea): string => {
    const members = idea.members.map(m => `- ${m.name} (${m.email})`).join('\n');
    return `
اسم المشروع: ${idea.projectName}
المقرر: ${idea.course}
مجال الفكرة: ${idea.field}
التقنيات المستخدمة: ${idea.technologies}
وصف المشكلة: ${idea.problemDescription}
الحل المقترح: ${idea.solution}
الأثر المحتمل: ${idea.impact}
الفئة المستهدفة: ${idea.targetAudience}
أعضاء الفريق:
${members}
    `.trim();
};

const App: React.FC = () => {
    const [step, setStep] = useState<Step>('input');
    const [idea, setIdea] = useState<ProjectIdea>({
        projectName: '',
        course: COURSES_DATA[0]?.name || '',
        field: FIELDS_LIST[0] || '',
        technologies: TECHNOLOGIES_LIST[0] || '',
        problemDescription: '',
        solution: '',
        impact: '',
        targetAudience: '',
        members: [{ name: '', email: '' }],
    });
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [agentStatuses, setAgentStatuses] = useState<Record<string, AgentStatus>>({
        'التحليل المبدئي': 'idle',
        'إنشاء التقرير التفصيلي': 'idle',
    });
    const [initialAnalysisResult, setInitialAnalysisResult] = useState<InitialAnalysisResult | null>(null);
    const [analysisReport, setAnalysisReport] = useState<AnalysisReport | null>(null);
    const [matchedIdea, setMatchedIdea] = useState<StoredIdea | null>(null);
    const [workspaceIdea, setWorkspaceIdea] = useState<ProjectIdea | null>(null);
    const [visualInspiration, setVisualInspiration] = useState<VisualInspirationBrief | null>(null);
    
    const [allIdeas, setAllIdeas] = useState<StoredIdea[]>([]);

     useEffect(() => {
        try {
            const savedIdeasRaw = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (savedIdeasRaw) {
                const savedIdeas = JSON.parse(savedIdeasRaw);
                 if (Array.isArray(savedIdeas) && savedIdeas.length > 0) {
                    setAllIdeas(savedIdeas);
                    return;
                }
            }
            setAllIdeas(EXISTING_IDEAS);
        } catch (error) {
            console.error("Failed to load ideas from localStorage, using default.", error);
            setAllIdeas(EXISTING_IDEAS);
        }
    }, []);

    const saveCurrentIdea = useCallback(() => {
        const newIdeaToSave: StoredIdea = {
            title: idea.projectName,
            course: idea.course,
            status: 'مسجل حديثًا',
            creationDate: new Intl.DateTimeFormat('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date()),
            problemDescription: idea.problemDescription,
            proposedSolution: idea.solution,
            potentialImpact: idea.impact,
            domain: idea.field,
            targetAudience: idea.targetAudience,
            link: '', // Add a default or leave empty
            contactEmail: idea.members[0]?.email || '' // Use first member's email as contact
        };

        const normalizedNewTitle = idea.projectName.toLowerCase().trim();
        if (!allIdeas.some(i => i.title.toLowerCase().trim() === normalizedNewTitle)) {
            const updatedIdeas = [...allIdeas, newIdeaToSave];
            setAllIdeas(updatedIdeas);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedIdeas));
        }
    }, [idea, allIdeas]);

    const resetStateForNewIdea = useCallback(() => {
        setStep('input');
        setIsLoading(false);
        setError(null);
        setAgentStatuses({
            'التحليل المبدئي': 'idle',
            'إنشاء التقرير التفصيلي': 'idle',
        });
        setAnalysisReport(null);
        setInitialAnalysisResult(null);
        setMatchedIdea(null);
        setWorkspaceIdea(null);
        setVisualInspiration(null);
    }, []);

    const handleSubmit = async () => {
        if (!idea.projectName.trim() || !idea.problemDescription.trim() || !idea.course) {
            setError('الرجاء اختيار مقرر وإدخال اسم المشروع ووصف المشكلة على الأقل.');
            return;
        }

        setIsLoading(true);
        setError(null);
        setAgentStatuses({ ...agentStatuses, 'التحليل المبدئي': 'running' });
        
        const fullIdeaDescription = serializeIdea(idea);
        const selectedCourse = COURSES_DATA.find(c => c.name === idea.course);
        if (!selectedCourse) {
            setError('المقرر المختار غير صالح.');
            setIsLoading(false);
            return;
        }

        const courseContext: CourseContext = {
            name: selectedCourse.name,
            objectives: selectedCourse.objectives,
            outcomes: selectedCourse.outcomes,
        };

        try {
            const result = await analyzeIdeaSimilarity(fullIdeaDescription, allIdeas, courseContext);
            setInitialAnalysisResult(result);

            if ((result.classification === 'SIMILAR' || result.classification === 'DUPLICATE') && result.similarToIndex !== null) {
                setMatchedIdea(allIdeas[result.similarToIndex]);
            }
            
            if (result.classification !== 'DUPLICATE') {
              saveCurrentIdea();
            }

            setAgentStatuses(prev => ({ ...prev, 'التحليل المبدئي': 'completed' }));
            setStep('summary');
        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'حدث خطأ غير معروف.';
            setError(`فشل التحليل المبدئي: ${errorMessage}`);
            setAgentStatuses(prev => ({ ...prev, 'التحليل المبدئي': 'error' }));
             // Show summary page even on error to allow user to retry
            setStep('summary');
        } finally {
            setIsLoading(false);
        }
    };

    const handleShowDetailedReport = async () => {
        if (!initialAnalysisResult) return;

        setIsLoading(true);
        setError(null);
        setAgentStatuses(prev => ({ ...prev, 'إنشاء التقرير التفصيلي': 'running' }));
        setStep('report');

        const fullIdeaDescription = serializeIdea(idea);

        try {
            let finalReport: AnalysisReport | null = null;
            const { classification } = initialAnalysisResult;

            if (classification === 'SIMILAR' && matchedIdea) {
                finalReport = await generateSimilarIdeaReport(fullIdeaDescription, matchedIdea);
            } else if (classification === 'DUPLICATE' && matchedIdea) {
                finalReport = await generateDuplicateIdeaReport(fullIdeaDescription, matchedIdea);
            } else { // UNIQUE
                finalReport = await generateVisualInspirationBrief(fullIdeaDescription);
                setVisualInspiration(finalReport as VisualInspirationBrief);
            }

            setAnalysisReport(finalReport);
            setAgentStatuses(prev => ({ ...prev, 'إنشاء التقرير التفصيلي': 'completed' }));
        } catch (e) {
            console.error(e);
            const errorMessage = e instanceof Error ? e.message : 'حدث خطأ غير معروف.';
            setError(`فشل إنشاء التقرير: ${errorMessage}`);
            setAgentStatuses(prev => ({ ...prev, 'إنشاء التقرير التفصيلي': 'error' }));
        } finally {
            setIsLoading(false);
        }
    };

    const handleSuggestMerge = () => {
        setStep('contact');
    };

    const handleStartDevelopment = () => {
        setWorkspaceIdea(idea);
        setStep('workspace');
    };

    const renderContent = () => {
        switch(step) {
            case 'input':
                return <IdeaInputForm 
                            idea={idea} 
                            setIdea={setIdea} 
                            onSubmit={handleSubmit}
                            isLoading={isLoading}
                            courses={COURSES_DATA}
                            fieldsList={FIELDS_LIST}
                            technologiesList={TECHNOLOGIES_LIST}
                        />;
            case 'summary':
                return <AnalysisSummary 
                            isLoading={isLoading}
                            result={initialAnalysisResult}
                            matchedIdea={matchedIdea}
                            error={error}
                            onProceed={handleShowDetailedReport}
                            onSuggestMerge={handleSuggestMerge}
                            onReturnToInput={resetStateForNewIdea}
                            onStartDevelopment={handleStartDevelopment}
                        />;
             case 'contact':
                return <ContactForm 
                            matchedIdea={matchedIdea}
                            onBack={() => setStep('summary')}
                        />;
            case 'workspace':
                if (!workspaceIdea) return null;
                return <ProjectWorkspace
                            idea={workspaceIdea}
                            inspiration={visualInspiration}
                            onBack={() => setStep('input')}
                       />;
            case 'report':
                 return (
                        <div>
                            <AgentPipeline statuses={agentStatuses} />
                            
                            {error && (
                                <div className="mt-6 p-4 bg-red-900/50 text-red-300 border border-red-700 rounded-lg">
                                    <p className="font-bold">خطأ</p>
                                    <p>{error}</p>
                                </div>
                            )}

                            <ResultDisplay
                                isLoading={isLoading}
                                report={analysisReport}
                                onReset={resetStateForNewIdea}
                            />
                        </div>
                    );
        }
    }
    
    return (
        <div className="min-h-screen bg-transparent text-gray-100 font-sans p-4 sm:p-6 lg:p-8 flex flex-col items-center">
            <div className="w-full max-w-5xl mx-auto">
                <header className="text-center mb-10">
                    <div className="flex items-center justify-center gap-4 mb-2">
                        <div className="p-2 bg-purple-900/50 rounded-lg border border-purple-700">
                           <EyeIcon className="w-12 h-12 text-cyan-400"/>
                        </div>
                         <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text">
                            عين طويق
                        </h1>
                    </div>
                    <p className="text-lg text-gray-400">نظام تحليل الأفكار متعدد الوكلاء الذكي</p>
                </header>

                <main className="bg-[#1A1A1A]/70 backdrop-blur-sm rounded-2xl shadow-2xl shadow-purple-900/50 p-6 md:p-8 border border-purple-500/30">
                    {renderContent()}
                </main>

                 <footer className="text-center mt-12 text-gray-500 text-sm">
                    <p>مدعوم بواسطة Google Gemini. أدخل فكرة مشروعك لترى العملاء الأذكياء في العمل.</p>
                </footer>
            </div>
        </div>
    );
};

export default App;