import React from 'react';
import { InitialAnalysisResult, StoredIdea } from '../types';
import { SparklesIcon, LightBulbIcon, DocumentDuplicateIcon, FolderIcon, LinkIcon, PencilIcon } from './Icons';

interface AnalysisSummaryProps {
    isLoading: boolean;
    result: InitialAnalysisResult | null;
    matchedIdea: StoredIdea | null;
    error: string | null;
    onProceed: () => void;
    onSuggestMerge: () => void;
    onReturnToInput: () => void;
    onStartDevelopment: () => void;
}

const SummaryCard: React.FC<{ icon: React.ReactNode; label: string; value: string | undefined | number }> = ({ icon, label, value }) => (
    <div className="flex flex-col items-center text-center gap-2">
        <div className="p-3 bg-gray-800 border border-gray-700 rounded-full">
            {icon}
        </div>
        <h3 className="text-lg font-semibold text-gray-200">{label}</h3>
        <p className="text-gray-400">{value || 'N/A'}</p>
    </div>
);


const AnalysisSummary: React.FC<AnalysisSummaryProps> = ({ isLoading, result, error, onProceed, onSuggestMerge, onReturnToInput, matchedIdea, onStartDevelopment }) => {
    if (isLoading && !result) {
        return <div className="text-center py-10 text-gray-400">يجري التحليل الأولي...</div>;
    }

    if (error) {
        return (
            <div className="text-center py-10">
                <h3 className="text-2xl font-bold text-red-400 mb-2">حدث خطأ</h3>
                <p className="text-red-300">{error}</p>
                 <button onClick={onReturnToInput} className="mt-4 px-6 py-2 font-semibold text-white bg-purple-600 rounded-lg hover:bg-purple-500 transition-colors">
                    المحاولة مرة أخرى
                </button>
            </div>
        );
    }
    
    if (!result) {
        return <div className="text-center py-10 text-gray-400">في انتظار نتيجة التحليل...</div>;
    }

    const renderContent = () => {
        switch (result.classification) {
            case 'UNIQUE':
                return (
                    <div className="flex flex-col items-center text-center p-6">
                        <img src="https://storage.googleapis.com/aai-web-template-files/06a03861-8032-4113-9118-095181b590e9.png" alt="Idea registered successfully" className="w-64 h-auto mb-6" />
                        <h2 className="text-3xl font-bold text-gray-100 mb-2">مبروك! فكرتك جديدة ومميزة</h2>
                        <p className="max-w-xl text-gray-400 mb-8">
                           تحليل "عين طويق" يؤكد أن فكرتك فريدة من نوعها ولا يوجد أي مشروع مشابه في النظام. يمكنك الآن الانطلاق في تطويرها.
                        </p>
                        <div className="flex gap-4">
                             <button onClick={onStartDevelopment} className="px-8 py-3 font-semibold text-white bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors">ابدأ تطوير المشروع</button>
                            <button onClick={onProceed} className="px-8 py-3 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-500 hover:to-blue-500 transition-all">احصل على إلهام مرئي</button>
                        </div>
                         <p className="text-xs text-gray-600 mt-4">سيتم إضافة فكرتك إلى قاعدة البيانات لمقارنتها مع الأفكار الجديدة.</p>
                    </div>
                );
            case 'SIMILAR':
                return (
                    <div className="flex flex-col items-center text-center p-6">
                        <div className="relative mb-6 flex justify-center items-center w-24 h-24">
                           <LightBulbIcon className="w-24 h-24 text-purple-400 opacity-30" />
                           <SparklesIcon className="w-16 h-16 text-cyan-400 absolute" />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-100 mb-2">تم العثور على فكرة مشابهة لمشروعك</h2>
                        <p className="max-w-2xl text-gray-400 mb-8">
                           {result.justification}
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-8 w-full max-w-3xl">
                           <SummaryCard icon={<PencilIcon className="w-8 h-8 text-cyan-400"/>} label="اسم المشروع" value={result.matchedProjectName} />
                           <SummaryCard icon={<LightBulbIcon className="w-8 h-8 text-cyan-400"/>} label="نسبة التشابه" value={`${result.similarityPercentage}%`} />
                           <SummaryCard icon={<FolderIcon className="w-8 h-8 text-cyan-400"/>} label="المقرر" value={result.matchedProjectCourse} />
                        </div>
                        <div className="flex gap-4">
                            <button onClick={onProceed} className="px-8 py-3 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-500 hover:to-blue-500 transition-all">التقرير التحليلي والاقتراحات</button>
                        </div>
                         <p className="text-xs text-gray-600 mt-4">تم حفظ هذه النتيجة في المستقبل.</p>
                    </div>
                );
            case 'DUPLICATE':
                 return (
                    <div className="flex flex-col items-center text-center p-6">
                         <div className="relative mb-6">
                           <img src="https://storage.googleapis.com/aai-web-template-files/8828d58c-8472-4d2a-b6d3-559d1a3c5a61.png" alt="Duplicate Idea" className="w-32 h-auto" />
                        </div>
                        <h2 className="text-3xl font-bold text-gray-100 mb-2">فكرتك مكررة من مشروع سابق</h2>
                        <p className="max-w-xl text-gray-400 mb-8">
                           تحليل "عين طويق" أظهر أن فكرتك متطابقة مع مشروع مسجل مسبقًا في المنصة. يمكنك مراجعة المشروع الأصلي أو تعديل فكرتك وإعادة التحليل.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 my-8 w-full max-w-xl">
                           <SummaryCard icon={<PencilIcon className="w-8 h-8 text-cyan-400"/>} label="اسم المشروع" value={result.matchedProjectName} />
                           <SummaryCard icon={<FolderIcon className="w-8 h-8 text-cyan-400"/>} label="المقرر" value={result.matchedProjectCourse} />
                        </div>
                        <div className="flex flex-wrap justify-center gap-4">
                            <button 
                                onClick={onSuggestMerge} 
                                disabled={!matchedIdea?.contactEmail}
                                className="px-8 py-3 font-semibold text-white bg-gray-800 rounded-lg hover:bg-gray-700 disabled:bg-gray-700 disabled:cursor-not-allowed disabled:opacity-50 transition-colors"
                            >
                                اقتراح دمج المشاريع
                            </button>
                            <button onClick={onProceed} className="px-8 py-3 font-semibold text-white bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg hover:from-purple-500 hover:to-blue-500 transition-all">التقرير التحليلي والاقتراحات</button>
                        </div>
                         <p className="text-xs text-gray-600 mt-4">تم حفظ هذه النتيجة في لوحة أعمالك. يمكنك تعديلها لاحقًا.</p>
                    </div>
                );
        }
    }
    
    return (
        <div className="w-full">
            {renderContent()}
        </div>
    );
};

export default AnalysisSummary;